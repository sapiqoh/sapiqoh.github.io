<!DOCTYPE html>
<html>
<head>
    <title>eFasiliti | Booking List</title>
    <link rel="stylesheet" href="">

    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>



<style>
          /* Style for confirm button */
          .confirm-booking-button {
            width: 100%;
            background-color: #28a745;
            color: #fff;
            cursor: pointer;
          }

           /* Hover effect for confirm Booking button */
          .confirm-booking-button:hover {
            background-color: #218838; /* Darker green color on hover */
          }

           /* Style for cancel button */
          .cancel-booking-button {
            width: 100%;
            background-color: #f44336;
            color: #fff;
            cursor: pointer;
          }

           /* Hover effect for cancel Booking button */
          .cancel-booking-button:hover {
            background-color: #f72819; /* Darker green color on hover */
          }
</style>



</head>
<body>
    
<?php include 'header-sidebar.php'; ?>

<main class="l-main">
  <div class="content-wrapper content-wrapper--with-bg">
    <h1 class="page-title">Booking List</h1>
    <div class="page-content">
      <!-- Content -->

      <table id="bookingTable" class="table table-hover table-bordered" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Telephone</th>
                    <th>Facility</th>
                    <th>Program</th>
                    <th>Date From</th>
                    <th>Date To</th>
                    <th>Time From</th>
                    <th>Time To</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <!-- Data will be populated here -->
                <?php
           
                // Connect to the database
                include 'db_conn.php';

                // Retrieve and display booking data
                $query = "SELECT * FROM bookings  ORDER BY dateBookMade DESC";
                $result = $conn->query($query);

                $counter = 1; // Initialize a counter variable

                while ($row = $result->fetch_assoc()) {
                    // Check if the status is equal to 0
                    $rowStyle = ($row['status'] == 0) ? 'background-color: #fffacd;' : '';

                    echo '<tr style="' . $rowStyle . '">';

                    echo "<td>".$counter."</td>"; // Display the counter value
                    echo "<td>".$row['nama']."</td>";
                    echo "<td>".$row['tel']."</td>";
                    echo "<td>".$row['facility']."</td>";
                    echo "<td>".$row['program']."</td>";
                    echo "<td>".$row['dateFrom']."</td>";
                    echo "<td>".$row['dateTo']."</td>";
                    echo "<td>".$row['timeFrom']."</td>";
                    echo "<td>".$row['timeTo']."</td>";
                    echo "<td>".$row['status']."</td>";
                    echo '<td>
                            <form method="post" action="confirm_booking.php">
                                <input type="hidden" name="booking_id" id = "booking_id" value="' . $row['id'] . '">
                                <input type="submit" value="Confirm" class="confirm-booking-button">
                            </form>
                            <form method="post" action="cancel_booking.php">
                                <input type="hidden" name="booking_id" id = "booking_id" value="' . $row['id'] . '">
                                <input type="submit" value="Cancel" class="cancel-booking-button">
                            </form>
                          </td>';
                    echo "</tr>";

                     $counter++; // Increment the counter
                }

                $conn->close();
                ?>
            </tbody>
        </table>


      <!-- end content-->
      
  
    </div>
  </div>
</main>

<!-- Include jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Include DataTables CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">

<!-- Include DataTables JavaScript -->
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready(function() {
        $('#bookingTable').DataTable({
            searching: true, // Enable searching
            // Add more DataTables options as needed
        });
    });


</script>



</body>
</html>
