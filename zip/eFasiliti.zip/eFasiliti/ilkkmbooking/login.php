<?php
// Connect to the database
include 'db_conn.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST["username"]) && isset($_POST["password"])) {
        $username = $_POST["username"];
        $password = $_POST["password"];

        // Use prepared statements to prevent SQL injection
        $query = "SELECT * FROM users WHERE username = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();
            
             // Authentication successful, start the session and redirect to dashboard
                session_start();
                $_SESSION["username"] = $username;
                header("Location: ../dashboard.php");

                exit();
                
        } else {
            echo "Invalid username or password";
        }

        $stmt->close();
    } else {
        echo "Please provide both username and password";
    }
}

$conn->close();
?>
