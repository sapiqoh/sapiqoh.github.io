<!DOCTYPE html>
<html>
<head>
<!-- Include SweetAlert library -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>


<body>

<?php

// Connect to the database
include 'db_conn.php';

$bookingId = $_POST["booking_id"];
    
$update_query = "UPDATE bookings SET status = 0 WHERE id = $bookingId";


$query = "SELECT * FROM bookings  WHERE id = $bookingId";
$result = $conn->query($query);
$row = $result->fetch_assoc();

if ($conn->query($update_query) === TRUE) {
    // Provide a response if needed
   echo "<script>
      Swal.fire({
        title: 'CANCEL BOOKING?',
        html: 'BOOKING DETAILS : <br><br> TEMPAT : ".$row['facility']." <br> PROGRAM : ".$row['program']." <br> TARIKH : (".$row['dateFrom'].") sehingga (".$row['dateTo'].") <br> MASA : ".$row['timeFrom']." - ".$row['timeTo']." <br><br> ',
        icon: 'info',
        showCancelButton: false,
        cancelButtonText: 'Cancel', // Change the cancel button text
        confirmButtonText: 'Confirm', // Change the confirm button text
        }).then((result) => {
            // If the user clicks Confirm, redirect to bookingPage.php
            if (result.isConfirmed) {
                window.location.href = 'bookingList.php';
            } 
        });
        </script>";
} else {
    // Handle invalid requests
    echo "Invalid request.";
}


$conn->close();
?>

</body>
</html>

