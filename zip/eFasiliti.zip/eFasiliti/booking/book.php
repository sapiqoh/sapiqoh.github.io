<!DOCTYPE html>
<html>

<head>
<!-- Include SweetAlert library -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>



<?php
// Create connection
include "db_conn.php";

// Set parameters and execute
// strtoupper will capitalize all value
$name = strtoupper($_REQUEST['name']);
$tel = strtoupper($_REQUEST['phone']);
$facility = strtoupper($_REQUEST['facility']);
$prog = strtoupper($_REQUEST['prog']);
$dateFrom = strtoupper($_REQUEST['date-from']);
$dateTo = strtoupper($_REQUEST['date-to']);
$timeFrom = strtoupper($_REQUEST['time-from']);
$timeTo = strtoupper($_REQUEST['time-to']);


// Prepare and bind SQL statement using prepared statements
$sql = "INSERT INTO bookings (nama, tel, facility, program, dateFrom, dateTo, timeFrom, timeTo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssssss", $name, $tel, $facility, $prog, $dateFrom, $dateTo, $timeFrom, $timeTo);

if ($stmt->execute()) {
  // Insertion successful
  echo "<script>
  Swal.fire({
    title: 'HI, $name',
    html: 'BOOKING DETAILS : <br><br> TEMPAT : $facility <br> PROGRAM : $prog <br> TARIKH : ($dateFrom) sehingga ($dateTo) <br> MASA : $timeFrom - $timeTo  <br><br> *note : Program anda akan ada di calendar selepas Admin sahkan tempahan <br>',
    icon: 'info',
    showCancelButton: false,
    cancelButtonText: 'Cancel', // Change the cancel button text
    confirmButtonText: 'Confirm', // Change the confirm button text
    }).then((result) => {
        // If the user clicks Confirm, redirect to bookingPage.php
        if (result.isConfirmed) {
            window.location.href = 'bookingPage.php';
        }
    });
        </script>";
}else {
    echo "ERROR: Sorry, there was an issue inserting the data: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>

</body>

</html>
