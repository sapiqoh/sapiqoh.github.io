<?php

// Create connection
include "db_conn.php";



// Retrieve events from the database
$sql = "SELECT dateFrom, dateTo, program, timeFrom, timeTo, facility, status FROM bookings where status = '1'";
$result = $conn->query($sql);

$events = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $event_date_from = $row["dateFrom"];
        $event_date_to = $row["dateTo"];
        $event_name = $row["program"] . '<br>' .'(' . $row["facility"] . ')';
        $event_time = $row["timeFrom"] . ' - ' . $row["timeTo"];
        
        // Convert date strings to DateTime objects
        $date_from = new DateTime($event_date_from);
        $date_to = new DateTime($event_date_to);
        
        // Iterate through the range of dates
        while ($date_from <= $date_to) {
            $event_date = $date_from->format('Y-m-d');
            
            if (!isset($events[$event_date])) {
                $events[$event_date] = array();
            }
            
            $events[$event_date][] = array(
                'name' => $event_name,
                'time' => $event_time,
            );
            
            $date_from->modify('+1 day');
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>eFasiliti | Admin Dashboard</title>
    <link rel="stylesheet"  href="calendar.css">

    <link href="" rel="stylesheet">
    <link href="" rel="stylesheet">
    <script src=""></script>

<style>


</style>

</head>
<body>
    
<?php include 'header-sidebar.php'; ?>

<main class="l-main">
  <div class="content-wrapper content-wrapper--with-bg">
    <h1 class="page-title">Dashboard</h1>
    <div class="page-content">

    <!-- calendar -->
    <div class="calendar">
    <div class="header">
      <button class="nav-button" id="prevButton">Prev</button>
      <div class="month-year">Month Year</div>
      <button class="nav-button" id="nextButton">Next</button>
    </div>
    <br><br>
    <div class="weekdays">
      <div class="weekday">Sun</div>
      <div class="weekday">Mon</div>
      <div class="weekday">Tue</div>
      <div class="weekday">Wed</div>
      <div class="weekday">Thu</div>
      <div class="weekday">Fri</div>
      <div class="weekday">Sat</div>
    </div>
    <div class="days" id="calendar">
      <!-- Day cells will be generated here -->
    </div>
  </div>

  <div class="event hide">
  <div class="event-name hide" data-time="${event.time}">
    ${event.name}
    <div class="event-time hide">${event.time}</div>
  </div>
  </div>

    </div>
  </div>
</main>

<script>
    const calendarContainer = document.getElementById('calendar');
        const monthNames = [
            "January", "February", "March", "April",
            "May", "June", "July", "August",
            "September", "October", "November", "December"
        ];

        let currentMonth = new Date().getMonth();
        let currentYear = new Date().getFullYear();
        
        //  get condifrmed events using PHP
       const events = <?php echo json_encode($events); ?>;
    

        function generateCalendar(year, month) {
            const numDays = new Date(year, month + 1, 0).getDate();
            const firstDay = new Date(year, month, 1).getDay();
            const monthName = monthNames[month];

            document.querySelector('.month-year').textContent = `${monthName} ${year}`;

            let calendarHTML = '';

            // Add empty cells for days before the first day of the month
            for (let i = 0; i < firstDay; i++) {
                calendarHTML += '<div class="empty"></div>';
            }

            for (let day = 1; day <= numDays; day++) {
                const date = `${year}-${(month + 1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
                const eventList = events[date] || [];
                const eventCount = eventList.length;

                const dayBox = document.createElement('div');
                dayBox.classList.add('day');
                dayBox.innerHTML = `
                    <span>${day}</span>
                    ${eventList
                        .map(event => `
                            <div class="event">
                                <div class="event-name" data-time="${event.time}">
                                    ${event.name}
                                    <div class="event-time hide">${event.time}</div>
                                </div>
                            </div>`)
                        .join('')}`;
                
                if (eventCount > 0) {
                    // Adjust the height of the day box based on the number of events
                    const adjustedHeight = 100 + (eventCount * 30); // Adjust the height as needed
                    dayBox.style.height = `${adjustedHeight}px`;
                }

                calendarHTML += dayBox.outerHTML;
            }

            calendarContainer.innerHTML = calendarHTML;
        }

    document.addEventListener('click', (event) => {
      const target = event.target;
      if (target.classList.contains('event-name')) {
        const eventTime = target.getAttribute('data-time');
        const timeDiv = target.querySelector('.event-time');
        
        if (eventTime && timeDiv) {
          timeDiv.textContent = eventTime;
          timeDiv.classList.toggle('show'); // Toggle the visibility of the time
        }
      }
    });

    generateCalendar(currentYear, currentMonth);

    prevButton.addEventListener('click', () => {
      if (currentMonth === 0) {
        currentMonth = 11;
        currentYear--;
      } else {
        currentMonth--;
      }
      clearCalendar();
      generateCalendar(currentYear, currentMonth);
    });

    nextButton.addEventListener('click', () => {
      if (currentMonth === 11) {
        currentMonth = 0;
        currentYear++;
      } else {
        currentMonth++;
      }
      clearCalendar();
      generateCalendar(currentYear, currentMonth);
    });

    function clearCalendar() {
      calendarContainer.innerHTML = ''; // Remove all child elements from the container
    }
</script>

    

</body>
</html>
