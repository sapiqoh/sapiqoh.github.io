<!DOCTYPE html>
<html lang="en">
<head>
  <!-- ... (head content) ... -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="styles.css">

</head>
<body class="sidebar-is-reduced">
  <!-- Header code ... -->
  <header class="l-header">
    <div class="l-header__inner clearfix">
      <div class="c-header-icon js-hamburger">
        <div class="hamburger-toggle"><span class="bar-top"></span><span class="bar-mid"></span><span class="bar-bot"></span></div>
      </div>
      <div class="header-icons-group">
        <div class="c-header-icon logout">
           <a href="../index.html">
          <i class="fa fa-power-off"></i>
        </a>
      </div>
    </div>
  </header>

  <!-- Sidebar code ... -->
  <div class="l-sidebar">
    <div class="logo">
      <div class="logo__txt"></div>
    </div>
    <div class="l-sidebar__content">
      <nav class="c-menu js-menu">
        <ul class="u-list">

        <li class="c-menu__item is-active" data-toggle="tooltip" title="Dashboard">
            <div class="c-menu__item__inner "><i class="fas fa-tachometer-alt"></i>
                <a href="index.php">
                    <div class="c-menu-item__title"><span>Dashboard</span></div>
                </a>
            </div>
        </li>

  
        <li class="c-menu__item has-submenu" data-toggle="tooltip" title="Booking">
            <div class="c-menu__item__inner "> <i class="fas fa-book"></i>
                <a href="bookingPage.php">
                    <div class="c-menu-item__title"><span>Booking</span></div>
                </a>
            </div>
        </li>

        </ul>
      </nav>
    </div>
  </div>


  <script>

let Dashboard = (() => {
  let global = {
    tooltipOptions: {
      placement: "right" },

    menuClass: ".c-menu" };


  let menuChangeActive = el => {
    let hasSubmenu = $(el).hasClass("has-submenu");
    $(global.menuClass + " .is-active").removeClass("is-active");
    $(el).addClass("is-active");

    // if (hasSubmenu) {
    // 	$(el).find("ul").slideDown();
    // }
  };

  let sidebarChangeWidth = () => {
    let $menuItemsTitle = $("li .menu-item__title");

    $("body").toggleClass("sidebar-is-reduced sidebar-is-expanded");
    $(".hamburger-toggle").toggleClass("is-opened");

    if ($("body").hasClass("sidebar-is-expanded")) {
      $('[data-toggle="tooltip"]').tooltip("destroy");
    } else {
      $('[data-toggle="tooltip"]').tooltip(global.tooltipOptions);
    }

  };

  return {
    init: () => {
      $(".js-hamburger").on("click", sidebarChangeWidth);

      $(".js-menu li").on("click", e => {
        menuChangeActive(e.currentTarget);
      });

      $('[data-toggle="tooltip"]').tooltip(global.tooltipOptions);
    } };

})();

Dashboard.init();

</script>


</body>
</html>
