<!DOCTYPE html>
<html>
<head>
    <title>eFasiliti | Booking Form</title>
    <link rel="stylesheet" href="booking.css">

</head>
<body>
    
<?php include 'header-sidebar.php'; ?>

<main class="l-main">
  <div class="content-wrapper content-wrapper--with-bg">
    <h1 class="page-title">Booking Form</h1>
    <div class="page-content">
      <!-- Content for your booking page goes here -->
      <div class="container">
        <center><h1>ILKKMSAS Facility Booking System</h1></center><br><br>
        
        <form method="post" action="book.php">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required><br><br>

            <label for="phone">No tel:</label>
            <input type="text" id="phone" name="phone" required><br><br>

            <label for="facility">Facility:</label>
            <select id="facility" name="facility" required>
                <option value="DWN">DEWAN SRI PERDANA</option>
                <option value="MK1/2">MAKMAL 1/2</option>
                <option value="MK3">MAKMAL 3</option>
                <option value="MK4">MAKMAL 4</option>
                <!-- Add more facilities as needed -->
            </select><br><br>

            <label for="prog">Program:</label>
            <input type="text" id="prog" name="prog" required> *(Jika nama program panjang, sila singkatkan [contoh : prg minda sihat])<br><br>


            <label for="date-from">Date From:</label>
            <input type="date" id="date-from" name="date-from" required> - 

            <label for="date-to">Date To:</label>
            <input type="date" id="date-to" name="date-to" required><br><br>

            <label for="time-from">Time From:</label>
            <input type="time" id="time-from" name="time-from" required> - 

            <label for="time-to">Time To:</label>
            <input type="time" id="time-to" name="time-to" required><br><br>

            <button type="submit" >Book Facility</button>
        </form>
    </div>
    </div>
  </div>
</main>

<script >
  // Get a reference to the date input element
  var dateFromInput = document.getElementById("date-from");
  var dateFromInput2 = document.getElementById("date-to");

  // Get the current date in the format "YYYY-MM-DD"
  var today = new Date().toISOString().split("T")[0];

  // Set the minimum date for the input to today
  dateFromInput.setAttribute("min", today);
  dateFromInput2.setAttribute("min", today);


</script>

</body>
</html>
